package net.phoenix.core.mixin.minecraft;

import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundEngine;
import net.phoenix.core.integration.vocal_vibrancy.VibrancyEvents;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SoundEngine.class)
public class SoundEngineMixin {

    @Inject(method = "play", at = @At("TAIL"))
    private void phoenix$onSoundPlay(SoundInstance sound, CallbackInfo ci) {
        // Trigger a custom event in Vocal Vibrancy whenever a sound starts.
        // This allows us to start the live FFT analysis for this specific sound instance.
        VibrancyEvents.onSoundStarted(sound);
    }
}
