package net.phoenix.core.integration.ponder;

import net.createmod.ponder.api.registration.PonderSceneRegistrationHelper;
import net.minecraft.resources.ResourceLocation;
import net.phoenix.core.PhoenixCore;
import net.phoenix.core.integration.ponder.multiblocks.GTPonderMultiblocks;
import net.phoenix.core.integration.ponder.multiblocks.GTPonderProcesses;
import net.minecraft.world.item.Item;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class PonderRegistrationManager {



    private static PonderSceneRegistrationHelper<ResourceLocation> helperInstance;

    private static final List<Consumer<PonderBuilder>> sceneRegistrars = new ArrayList<>();
    private static final List<Consumer<PonderTagBuilder>> tagRegistrars = new ArrayList<>();

    // This now matches the field above
    public static void setHelper(PonderSceneRegistrationHelper<ResourceLocation> helper) {
        helperInstance = helper;
    }

    public static void register(Consumer<PonderBuilder> registrar) {
        sceneRegistrars.add(registrar);
    }

    public static void registerTags(Consumer<PonderTagBuilder> registrar) {
        tagRegistrars.add(registrar);
    }

    public static void load() {
        // Safety check: Don't proceed if the helper isn't ready
        if (helperInstance == null) {
            PhoenixCore.LOGGER.error("PonderRegistrationManager.load() called before helper was set!");
            return;
        }

        PonderBuilder ponderBuilder = new PonderBuilder(helperInstance);

        for (Consumer<PonderBuilder> registrar : sceneRegistrars) {
            registrar.accept(ponderBuilder);
        }

        GTPonderMultiblocks.registerAllMultiblockScenes(ponderBuilder);
        GTPonderProcesses.register(ponderBuilder);

        PonderTagBuilder tagBuilder = new PonderTagBuilder();
        for (Consumer<PonderTagBuilder> registrar : tagRegistrars) {
            registrar.accept(tagBuilder);
        }
        tagBuilder.register();
    }
}