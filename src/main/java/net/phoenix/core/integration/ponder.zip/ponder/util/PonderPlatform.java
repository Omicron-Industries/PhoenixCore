package net.phoenix.core.integration.ponder.util;

import net.minecraft.core.particles.ParticleType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.stream.Stream;

public class PonderPlatform {

    public static Stream<ParticleType<?>> getParticleTypes() {
        return ForgeRegistries.PARTICLE_TYPES.getValues().stream();
    }

    public static ResourceLocation getParticleTypeName(ParticleType<?> particleType) {
        return ForgeRegistries.PARTICLE_TYPES.getKey(particleType);
    }

    public static ResourceLocation getBlockName(Block block) {
        return ForgeRegistries.BLOCKS.getKey(block);
    }

    public static ResourceLocation getEntityTypeName(EntityType<?> entityType) {
        return ForgeRegistries.ENTITY_TYPES.getKey(entityType);
    }

    public static ResourceLocation getItemName(Item item) {
        return ForgeRegistries.ITEMS.getKey(item);
    }
}
