package net.phoenix.core.integration.ponder;

import net.createmod.ponder.api.registration.PonderSceneRegistrationHelper;
import net.createmod.ponder.api.scene.PonderStoryBoard;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;

import net.phoenix.core.PhoenixCore;
import net.phoenix.core.integration.ponder.api.ExtendedPonderStoryBoard;
import net.phoenix.core.integration.ponder.api.ExtendedSceneBuilder;
import net.phoenix.core.integration.ponder.api.SceneBuildingUtilDelegate;
import net.phoenix.core.integration.ponder.util.PonderErrorHelper;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import org.jetbrains.annotations.NotNull;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class PonderBuilder {
    private final PonderSceneRegistrationHelper<ResourceLocation> helper;
    private final Set<Item> items = new HashSet<>();

    public PonderBuilder(PonderSceneRegistrationHelper<ResourceLocation> helper) {
        this.helper = helper;
    }

    public PonderBuilder forItems(Ingredient ingredient) {
        if (!ingredient.isEmpty()) {
            this.items.addAll(Arrays.stream(ingredient.getItems())
                    .map(ItemStack::getItem)
                    .collect(Collectors.toSet()));
        }
        return this;
    }

    public PonderBuilder scene(String name, String title, ExtendedPonderStoryBoard scene) {
        return scene(name, title, "phoenixcore:gregtech_multiblocks/blank_64", scene);
    }

    /**
     * @param name          scene id path (e.g. "gregtech_multiblocks/electric_blast_furnace")
     *                      — the phoenixcore namespace is prepended automatically.
     * @param title         human-readable title registered via registerSharedText.
     * @param structureName full namespaced schematic id string
     *                      (e.g. "phoenixcore:gregtech_multiblocks/blank_64").
     *                      Passed directly as a ResourceLocation — NOT run through
     *                      appendPonderJSNamespaceToId.
     * @param scene         storyboard lambda.
     */
    public PonderBuilder scene(String name, String title, String structureName, ExtendedPonderStoryBoard scene) {
        // Scene id: prepend phoenixcore namespace via appendPonderJSNamespaceToId
        ResourceLocation id = PhoenixCore.appendPonderJSNamespaceToId(name);
        // Schematic: parse as raw ResourceLocation — never mangle with appendPonderJSNamespaceToId
        ResourceLocation structureId = new ResourceLocation(structureName);
        PonderStoryBoardWrapper wrapper = new PonderStoryBoardWrapper(scene);

        for (var item : items) {
            ResourceLocation itemId = net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(item);
            if (itemId == null) continue;

            helper.addStoryBoard(itemId, structureId,
                    (builder, util) -> {
                        builder.title(id.getPath(), title);
                        wrapper.program(builder, util);
                    }, id);
        }
        return this;
    }

    public void register() {}

    public static class PonderStoryBoardWrapper implements PonderStoryBoard {
        private final ExtendedPonderStoryBoard storyBoard;

        protected PonderStoryBoardWrapper(ExtendedPonderStoryBoard storyBoard) {
            this.storyBoard = storyBoard;
        }

        @Override
        public void program(@NotNull SceneBuilder builder, @NotNull SceneBuildingUtil util) {
            try {
                ExtendedSceneBuilder extended = new ExtendedSceneBuilder(builder);
                storyBoard.program(extended, new SceneBuildingUtilDelegate(util));
            } catch (Exception e) {
                PonderErrorHelper.yeet(e);
            }
        }
    }
}