package net.phoenix.core.integration.ponder;

import net.createmod.ponder.api.registration.PonderSceneRegistrationHelper;
import net.createmod.ponder.api.scene.PonderStoryBoard;
import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.createmod.ponder.foundation.PonderScene;

import net.phoenix.core.PhoenixCore;

import net.phoenix.core.integration.ponder.api.ExtendedPonderStoryBoard;
import net.phoenix.core.integration.ponder.api.ExtendedSceneBuilder;
import net.phoenix.core.integration.ponder.api.SceneBuildingUtilDelegate;
import net.phoenix.core.mixin.SceneBuilderAccessor;
import net.phoenix.core.integration.ponder.util.PonderErrorHelper;
import net.phoenix.core.integration.ponder.util.PonderPlatform;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class PonderStoryBoardWrapper implements PonderStoryBoard {
    private final ExtendedPonderStoryBoard storyBoard;

    protected PonderStoryBoardWrapper(ExtendedPonderStoryBoard storyBoard) {
        this.storyBoard = storyBoard;
    }

    @Override
    public void program(SceneBuilder builder, SceneBuildingUtil util) {
        try {
            // Wrap the builder directly — don't extract the scene and make a new builder
            ExtendedSceneBuilder extended = new ExtendedSceneBuilder(builder);
            storyBoard.program(extended, new SceneBuildingUtilDelegate(util));
        } catch (Exception e) {
            PonderErrorHelper.yeet(e);
        }
    }
}
